#define PACKET_TRANSACTION_INSTANCE(name, dev) extern int alt_no_storage
#define PACKET_TRANSACTION_INIT(name, dev) while (0)